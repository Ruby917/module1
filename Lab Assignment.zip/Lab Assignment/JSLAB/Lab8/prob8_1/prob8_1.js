function calculatePayment(){
	var a= document.loan.amount.value;
	var r= document.loan.rate.value;
	var p= document.loan.period.value;
	var mp;
	var tp;
	var ip;
	if(a>1500000){
		alert("amount should be less than 15 lacs");
	}
	else if(p<7 && p>15){
		alert("period should be between 7 years and 15 years");
	}
	else{
		p = p*12;
		mp = a * r/ (1 - (math.pow(1/(1 + r), p)));
		tp = mp * p;
		ti = tp -(p*a);
		document.loan.mpayment.value=mp;
		document.loan.tpayment.value=tp;
		document.loan.tinterest.value=ip;
	}
	
}